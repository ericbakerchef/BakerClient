register("renderWorld", () => {
    World.getAllEntities().forEach(e => {
        Tessellator.drawString(
            "§aENT",
            e.getX(),
            e.getY() + 1,
            e.getZ(),
            0x00FF00,
            1.5,
            false,
            false
        )
    })
})
