import Config from "./config"

export default {
    imageUrl: "https://i.imgur.com/LRdNTl5.png",
};