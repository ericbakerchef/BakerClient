import Config from "./config"

const bmw = new Image("bmw.png", "https://imgur.com/LRdNTl5")

function getPixels() {
    const sw = Renderer.screen.getWidth()
    const sh = Renderer.screen.getHeight()

    // Compute pixel size
    const w = (Config.imageWidth / 100) * sw
    const h = (Config.imageHeight / 100) * sh

    // Clamp position so it never leaves the screen
    const x = Math.max(0, Math.min(sw - w, (Config.imageX / 100) * sw))
    const y = Math.max(0, Math.min(sh - h, (Config.imageY / 100) * sh))

    return { x, y, w, h }
}

register("renderOverlay", () => {
    if (!Config.bmw) return
    const p = getPixels()
    bmw.draw(p.x, p.y, p.w, p.h)
})

register("command", (...args) => {
    if (args.length !== 5 || args[0] !== "setconfig") {
        ChatLib.chat("&cUsage: /bmw setconfig <height> <width> <x> <y>")
        return
    }

    const height = parseFloat(args[1])
    const width = parseFloat(args[2])
    const x = parseFloat(args[3])
    const y = parseFloat(args[4])

    if ([height, width, x, y].some(v => isNaN(v))) {
        ChatLib.chat("&cInvalid numbers!")
        return
    }

    Config.imageHeight = Math.max(1, Math.min(100, height))
    Config.imageWidth = Math.max(1, Math.min(100, width))
    Config.imageX = Math.max(0, Math.min(100, x))
    Config.imageY = Math.max(0, Math.min(100, y))

    ChatLib.chat(`&aBMW config updated: height=${Config.imageHeight}, width=${Config.imageWidth}, x=${Config.imageX}, y=${Config.imageY}`)
}).setName("bmw")
