import Config from "./config"

const EntityArmorStand = Java.type("net.minecraft.entity.item.EntityArmorStand")

const PESTS = [
    "Beetle", "Cricket", "Dragonfly", "Earthworm", "Field Mouse", 
    "Firefly", "Fly", "Locust", "Mite", "Mosquito", 
    "Moth", "Praying Mantis", "Rat", "Slug"
]

register("renderWorld", (pt) => {
    if (!Config.pestesp) return

    World.getAllEntities().forEach(e => {
        const ent = e.getEntity()
        if (!(ent instanceof EntityArmorStand)) return

        const rawName = e.getName()
        if (!rawName) return

        const cleanName = ChatLib.removeFormatting(rawName)

        const pestName = PESTS.find(p => cleanName.includes(p))
        if (!pestName) return

        Tessellator.drawString(
            pestName,        
            e.getX(),
            e.getY() + 2.5,  
            e.getZ(),
            0xFF1E1E,       
            Config.pestespesp,          
            2.5              
        )
    })
})
