import Config from "./config"

let timer = 0

register("step", () => {
    if (!Config.autotip) return

    timer++

    if (timer >= Config.autotipdelay * 80) {
        ChatLib.command("tipall")
        timer = 0
    }
})