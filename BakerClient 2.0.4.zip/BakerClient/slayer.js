/// <reference types="../CTAutocomplete" />

import Config from "./config"; // Contains slayercarry & slayerprice

let hudX = 10;
let hudY = 10;

let dragging = false;
let offsetX = 0;
let offsetY = 0;

// ======================
// TRACKER VALUES
// ======================
let totalKills = 0;
let killsLeft = 0;
let paid = 0;
let debt = 0;
let targetPlayer = ""; // Stores the player name for HUD

// ======================
// HUD SIZING
// ======================
const width = 200;
const lineHeight = 10;
const padding = 4;
const height = lineHeight * 6 + padding * 2; // no gaps

// ======================
// HELPERS
// ======================
function formatNumber(num) {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

function parseCoins(input) {
    const str = input.toLowerCase().replace(/,/g, "");

    let multiplier = 1;

    if (str.endsWith("k")) multiplier = 1_000;
    else if (str.endsWith("m")) multiplier = 1_000_000;
    else if (str.endsWith("million")) multiplier = 1_000_000;

    const numberPart = parseFloat(str);
    if (isNaN(numberPart)) return null;

    return Math.round(numberPart * multiplier);
}

// ======================
// RENDER HUD
// ======================
register("renderOverlay", () => {
    if (!Config.slayercarry) return;

    Renderer.drawRect(
        Renderer.color(0, 0, 0, 120),
        hudX - padding,
        hudY - padding,
        width,
        height
    );

    let y = hudY;

    // 1. Heading
    Renderer.drawStringWithShadow(
        "§c§lSlayer Carry Tracker",
        hudX,
        y
    );
    y += lineHeight;

    // 2. Total Kills
    Renderer.drawStringWithShadow(
        `§cTotal Kills: §f${formatNumber(totalKills)}`,
        hudX,
        y
    );
    y += lineHeight;

    // 3. Kills Left
    Renderer.drawStringWithShadow(
        `§cKills Left: §f${formatNumber(killsLeft)}`,
        hudX,
        y
    );
    y += lineHeight;

    // 4. Paid
    Renderer.drawStringWithShadow(
        `§aPaid: §f$${formatNumber(paid)}`,
        hudX,
        y
    );
    y += lineHeight;

    // 5. Debt
    const debtColor = debt < 0 ? "§c" : "§e";
    Renderer.drawStringWithShadow(
        `§6Debt: ${debtColor}$${formatNumber(debt)}`,
        hudX,
        y
    );
    y += lineHeight;

    // 6. For: player (label blue, name white)
    Renderer.drawStringWithShadow(
        `§bFor: §f${targetPlayer}`,
        hudX,
        y
    );
});

// ======================
// DRAGGING
// ======================
register("guiMouseClick", (x, y, button) => {
    if (!Config.slayercarry || button !== 0) return;

    if (
        x >= hudX - padding && x <= hudX + width &&
        y >= hudY - padding && y <= hudY + height
    ) {
        dragging = true;
        offsetX = x - hudX;
        offsetY = y - hudY;
    }
});

register("guiMouseDrag", (x, y) => {
    if (!dragging) return;

    hudX = x - offsetX;
    hudY = y - offsetY;
});

register("guiMouseRelease", () => {
    dragging = false;
});

// ======================
// COMMANDS
// ======================

// Log coins (adds to paid, debt updates normally)
register("command", (amount) => {
    if (!amount) {
        ChatLib.chat("§cUsage: /logcoins <number>");
        return;
    }

    const change = parseCoins(amount);
    if (change === null) {
        ChatLib.chat("§cInvalid number.");
        return;
    }

    paid += change;
    debt += change;

    ChatLib.chat(
        `§aPayment logged: §f$${formatNumber(change)} §7| §6Debt: §e$${formatNumber(debt)}`
    );
}).setName("logcoins");

// Log kills
register("command", (amount) => {
    if (!amount || isNaN(amount)) {
        ChatLib.chat("§cUsage: /logkills <number>");
        return;
    }

    const change = parseInt(amount);

    totalKills += change;
    killsLeft -= change;

    ChatLib.chat(
        `§aKills logged: §f+${formatNumber(change)} §7| §cKills Left: §f${formatNumber(killsLeft)}`
    );
}).setName("logkills");

// /slayer setconfig <num> <player>
register("command", (...args) => {
    if (!args[0] || args[0].toLowerCase() !== "setconfig") {
        ChatLib.chat("§cUsage: /slayer setconfig <killsLeft> <playerName>");
        return;
    }

    const killsLeftNum = parseInt(args[1]);
    const playerName = args[2];

    if (isNaN(killsLeftNum) || !playerName) {
        ChatLib.chat("§cUsage: /slayer setconfig <killsLeft> <playerName>");
        return;
    }

    totalKills = 0;
    killsLeft = killsLeftNum;
    paid = 0;
    debt = -1 * killsLeftNum * Config.slayerprice * 100000; // <-- negative debt
    targetPlayer = playerName;

    ChatLib.chat(`§aSlayer tracker set for §f${playerName}§a!`);
    ChatLib.chat(`§cKills Left: §f${formatNumber(killsLeft)} §a| Debt: §e$${formatNumber(debt)}`);
}).setName("slayer");
// ======================
// /slayerhelp command
// ======================
// /slayerhelp
register("command", () => {
    ChatLib.chat("§0[§fslayer settings§0]");
    ChatLib.chat(" ");
    ChatLib.chat("  §b/slayer setconfig <killsLeft> <playername> §7- starting command");
    ChatLib.chat("  §b/logcoins <amount> §7- Log coins manually");
    ChatLib.chat("  §b/logkills <number> §7- Log kills completed");
    ChatLib.chat("");
}).setName("slayerhelp");
