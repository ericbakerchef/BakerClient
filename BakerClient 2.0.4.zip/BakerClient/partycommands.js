import Config from "./config"

function getCoordsMessage() {

    const x = Player.getX();
    const y = Player.getY();
    const z = Player.getZ();
    const rx = Math.round(x);
    const ry = Math.round(y);
    const rz = Math.round(z);

    return `pc x: ${rx}, y: ${ry}, z: ${rz}`;
}


register('chat', () => {
    if(Config.test) {
    setTimeout(() => {
        ChatLib.command("pc test");
    },200)}
}).setCriteria(/^Party > (?:\\[(.*?)\\] )?(.+?) ?(?:\u127E|\u2692)?: !test$/)

register("chat", () => {
    if(Config.gentref) {
    setTimeout(() => {
        ChatLib.command("pc Gentlemen Reference")
    },200)
    setTimeout(() => {
        ChatLib.command("pc they call him 007")
    },1200)
    setTimeout(() => {
        ChatLib.command("pc 0 times ee2 done")
    },2200)
    setTimeout(() => {
        ChatLib.command("pc 0 dps")
    },3200)
    setTimeout(() => {
        ChatLib.command("pc 7/7 right lever")
    },4200)}
}).setCriteria(/^Party > (?:\\[(.*?)\\] )?(.+?) ?(?:\u127E|\u2692)?: !gentref$/)

register("chat", () => {
    if(Config.gentbookref) {
    setTimeout(() => {
        ChatLib.command("pc So what happened was i went to the mall with somebody")
    },200)

    setTimeout(() => {
        ChatLib.command("pc we went to this bookstore (alr its store for books)")
    },1200)

    setTimeout(() => {
        ChatLib.command("pc we went to manga section we were lookin at wrong")
    },2200)

    setTimeout(() => {
        ChatLib.command("pc i grabbed the book, like skin through the pages")
    },3200)

    setTimeout(() => {
        ChatLib.command("pc and then i see 1 page the page was just literly pantys")
    },4200)

    setTimeout(() => {
        ChatLib.command("pc so my smart (in that mumble) as decided to sniff here, i went")
    },5200)

    setTimeout(() => {
        ChatLib.command("pc SNIFF")
    },6200)

    setTimeout(() => {
        ChatLib.command("pc like i was snoring c*ke")
    },7200)

    setTimeout(() => {
        ChatLib.command("pc then i turn the page, and who do i see?")
    },8200)

    setTimeout(() => {
        ChatLib.command("pc a little girl holding the pantys")
    },9200)

    setTimeout(() => {
        ChatLib.command("pc so i ran out")
    },10200)

    setTimeout(() => {
        ChatLib.command("pc -gentlemen1210")
    },11200)}
}).setCriteria(/^Party > (?:\\[(.*?)\\] )?(.+?) ?(?:\u127E|\u2692)?: !gentbookref$/)

register("chat", () => {
    if(Config.real) {
    setTimeout(() => {
        ChatLib.command("pc so real")
    },200)}
}).setCriteria(/^Party > (?:\\[(.*?)\\] )?(.+?) ?(?:\u127E|\u2692)?: !real$/)

register("chat", () => {
    if(Config.crash) {
    setTimeout(() => {
        ChatLib.command("pc you are fat")
    },200)}
}).setCriteria(/^Party > (?:\\[(.*?)\\] )?(.+?) ?(?:\u127E|\u2692)?: !crash$/)

register("chat", () => {
    if(Config.limbo) {
    setTimeout(() => {
        ChatLib.command("pc you are gent")
    },200)}
}).setCriteria(/^Party > (?:\\[(.*?)\\] )?(.+?) ?(?:\u127E|\u2692)?: !limbo$/)

register("chat", () => {
    if(Config.meta) {
    setTimeout(() => {
        ChatLib.command("pc so meta")
    },200)}
}).setCriteria(/^Party > (?:\\[(.*?)\\] )?(.+?) ?(?:\u127E|\u2692)?: !meta$/)

register("chat", () => {
    if(Config.math) {
    setTimeout(() => {
        ChatLib.command("pc 6 * 2 = 2")
    },200)
    setTimeout(() => {
        ChatLib.command("pc 1% of 100 is 10")
    },200)
    setTimeout(() => {
        ChatLib.command("pc -gentlemen1210")
    },1200)}
}).setCriteria(/^Party > (?:\\[(.*?)\\] )?(.+?) ?(?:\u127E|\u2692)?: !math$/)

register("chat", () => {
    if(Config.redstoneref) {
    setTimeout(() => {
        ChatLib.command("pc use wither cloak it works every time")
    },200)
     setTimeout(() => {
        ChatLib.command("pc badlion is the superior 1.8.9 its not my pc")
    },1200)
     setTimeout(() => {
        ChatLib.command("pc 1.21 is the future of skyblock")
    },2200)
      setTimeout(() => {
        ChatLib.command("pc surely i profit from this update")
    },3200)
      setTimeout(() => {
        ChatLib.command("pc hey stop twisting my words")
    },4200)
      setTimeout(() => {
        ChatLib.command("pc You have 37 pending Bestiary Milestones to be claimed!")
    },5200)}
}).setCriteria(/^Party > (?:\\[(.*?)\\] )?(.+?) ?(?:\u127E|\u2692)?: !redstoneref$/)

register("chat", () => {
    if(Config.adminref) {
    setTimeout(() => {
        ChatLib.command("pc thefat987")
    },200)
    setTimeout(() => {
        ChatLib.command("pc stop eating")
    },1200)
    setTimeout(() => {
        ChatLib.command("pc there is not enough spot for TheAdmin987! pls check for weight cap")
    },2200)}
}).setCriteria(/^Party > (?:\\[(.*?)\\] )?(.+?) ?(?:\u127E|\u2692)?: !adminref$/)

register("chat", () => {
    if(Config.ericref) {
    setTimeout(() => {
        ChatLib.command("pc Party > [MVP+] FurryPawsUwU: he really wanted runs?")
    },200)
    setTimeout(() => {
        ChatLib.command("pc Party > [MVP+] FurryPawsUwU: weird")
    },1200)}
}).setCriteria(/^Party > (?:\\[(.*?)\\] )?(.+?) ?(?:\u127E|\u2692)?: !ericref$/)

register("chat", () => {
    if(Config.penguinref) {
    setTimeout(() => {
        ChatLib.command("pc how could penguin have ref?????")
    },200)
    setTimeout(() => {
        ChatLib.command("pc bros peak meta player")
    },1200)}
}).setCriteria(/^Party > (?:\\[(.*?)\\] )?(.+?) ?(?:\u127E|\u2692)?: !penguinref$/)

register("chat", () => {
    if(Config.maddyref) {
    setTimeout(() => {
        ChatLib.command("pc meow meow meow")
    },200)
    setTimeout(() => {
        ChatLib.command("pc im a good mage if you want 1 run per month")
     },1200)
    setTimeout(() => {
        ChatLib.command("pc fine i wont dps")
    },2200)}
}).setCriteria(/^Party > (?:\\[(.*?)\\] )?(.+?) ?(?:\u127E|\u2692)?: !maddyref$/)

register("chat", () => {
    if(Config.meow) {
    setTimeout(() => {
        ChatLib.command("pc meow")
    },200)
    setTimeout(() => {
        ChatLib.command("pc mraow")
    },1200)
    setTimeout(() => {
        ChatLib.command("pc mrrp nyah")
    },2200)
    setTimeout(() => {
        ChatLib.command("pc mrrow")
    },3200)
    setTimeout(() => {
        ChatLib.command("pc :3")
    },4200)}
}).setCriteria(/^Party > (?:\\[(.*?)\\] )?(.+?) ?(?:\u127E|\u2692)?: !meow$/)

register("chat", () => {
    if(Config.ref) {
    setTimeout(() => {
        ChatLib.command("pc gent ref")
    },200)}
}).setCriteria(/^Party > (?:\\[(.*?)\\] )?(.+?) ?(?:\u127E|\u2692)?: !ref$/)

register("chat", () => {
    if(Config.bakerhelp) {
    setTimeout(() => {
        ChatLib.command("pc !bakerclient, !bakerhelp, !gentref, !gentbookref, !real, !crash, !limbo, !meta, !adminref, !redstoneref, !penguinref, !maddyref, !meow, !ref")
    },200)
    setTimeout(() => {
        ChatLib.command("pc !clip, !diana, !oliref, !math, !hazelref, !devref, !roseref, !ericref, !hamiltonref, !leonref, !martinasref, !jqnxcref")
    },1200)
   setTimeout(() => {
        ChatLib.command("pc !67, !thearef, !stenoref, !hozoniref, !melonref, 67, !dt, 1s, !harryref, !dexref, !eggcurdref, !joshieref")
    },2200)}
}).setCriteria(/^Party > (?:\\[(.*?)\\] )?(.+?) ?(?:\u127E|\u2692)?: !bakerhelp$/)

register("chat", () => {
    if(Config.eggcurdref) {
    setTimeout(() => {
        ChatLib.command("pc im gooning to your mining bro")
    },200)
    setTimeout(() => {
        ChatLib.command("pc eric you suck at everything and i hate you for existing")
    },1200)
    setTimeout(() => {
        ChatLib.command("pc ill host the server after i get level 524")
    },2200)
    setTimeout(() => {
        ChatLib.command("pc hamilton is my will to live")
    },3200)
    setTimeout(() => {
        ChatLib.command("pc 90 chimera 8 dyes 60 wools 40 phoenix 650 fragments 1.5b/hr")
    },4200)}
}).setCriteria(/^Party > (?:\\[(.*?)\\] )?(.+?) ?(?:\u127E|\u2692)?: !eggcurdref$/)

register("chat", () => {
    if(Config.hamiltonref) {
    setTimeout(() => {
        ChatLib.command("pc john jay got sick after writing 5")
    },200)
    setTimeout(() => {
        ChatLib.command("pc james madison wrote 29")
    },1200)
    setTimeout(() => {
        ChatLib.command("pc HAMILTON WROTE")
    },2200)
    setTimeout(() => {
        ChatLib.command("pc THE OTHER 51")
    },3200)}
}).setCriteria(/^Party > (?:\\[(.*?)\\] )?(.+?) ?(?:\u127E|\u2692)?: !hamiltonref$/)

register("chat", () => {
    if(Config.joshieref) {
    setTimeout(() => {
        ChatLib.command("pc erics a femboy i just cant prove it")
    },200)}
}).setCriteria(/^Party > (?:\\[(.*?)\\] )?(.+?) ?(?:\u127E|\u2692)?: !joshieref$/)

register("chat", () => {
    if(Config.bakerclient) {
    setTimeout(() => {
        ChatLib.command("pc Add ericbakerchef on Discord")
    },200)
    setTimeout(() => {
        ChatLib.command("pc Note that this mod isn't very polished and not really mean't for anyone else to use.")
    },1200)}
}).setCriteria(/^Party > (?:\\[(.*?)\\] )?(.+?) ?(?:\u127E|\u2692)?: !bakerclient$/)

register("chat", () => {
    if(Config.clip) {
    setTimeout(() => {
        ChatLib.command("pc Failed to load clip: Weight limit exceeded by 500%!")
    },200)}
}).setCriteria(/^Party > (?:\\[(.*?)\\] )?(.+?) ?(?:\u127E|\u2692)?: !clip$/)

register("chat", () => {
    if(Config.diana) {
    setTimeout(() => {
        ChatLib.command("p inq menacingcondom38 shegaveconsent indianstreetfood n_word")
    },200)}
}).setCriteria(/^Party > (?:\\[(.*?)\\] )?(.+?) ?(?:\u127E|\u2692)?: !diana$/)

register("chat", () => {
    if(Config.oliref) {
    setTimeout(() => {
        ChatLib.command("pc 08Master Reference")
    },200)
    setTimeout(() => {
        ChatLib.command("pc They call him 007")
    },1200)
    setTimeout(() => {
        ChatLib.command("pc 0 bank")
    },2200)
    setTimeout(() => {
        ChatLib.command("pc 0 chims")
    },3200)
    setTimeout(() => {
        ChatLib.command("pc 7k spent on gems")
    },4200)}
}).setCriteria(/^Party > (?:\\[(.*?)\\] )?(.+?) ?(?:\u127E|\u2692)?: !oliref$/)

register("chat", () => {
    if(Config.ingreenroom) {
        ChatLib.command("pc In Green Room")
    }
}). setCriteria("Starting in 4 seconds.")
// Diana drop notifiers bcs no other 1.8 mod has them

register("chat", () => {
    if (Config.wool) {
    setTimeout(() => {
        ChatLib.command("pc [BakerClient] Rare Drop: Shimmering Wool!")
    },200)}
}).setCriteria("RARE DROP! Shimmering Wool")

register("chat", () => {
    if (Config.relic) {
    setTimeout(() => {
        ChatLib.command("pc [BakerClient] Rare Drop: Minos Relic!")
    },200)}
}).setCriteria("RARE DROP! Minos Relic")

register("chat", () => {
    if (Config.chimera) {
    setTimeout(() => {
        ChatLib.command("pc [BakerClient] Rare Drop: Chimera!")
    },200)}
}).setCriteria("RARE DROP! Enchanted Book (Chimera I)")

register("chat", () => {
    if (Config.frag) {
    setTimeout(() => {
        ChatLib.command("pc [BakerClient] Rare Drop: Mythos Fragment!")
    },200)}
}).setCriteria("RARE DROP! You dug out a Mythos Fragment!")

register("chat", () => {
    if (Config.feather) {
    setTimeout(() => {
        ChatLib.command("pc [BakerClient] Rare Drop: Braided Griffin Feather!")
    },200)}
}).setCriteria("RARE DROP! You dug out a Braided Griffin Feather!")

register("chat", () => {
    if (Config.stinger) {
    setTimeout(() => {
        ChatLib.command("pc [BakerClient] Rare Drop: Fateful Stinger!")
    },200)}
}).setCriteria("RARE DROP! Fateful Stinger")

register("chat", () => {
    if (Config.food) {
    setTimeout(() => {
        ChatLib.command("pc [BakerClient] Rare Drop: Brain Food!")
    },200)}
}).setCriteria("RARE DROP! Brain Food")

register("chat", () => {
    if (Config.core) {
    setTimeout(() => {
        ChatLib.command("pc [BakerClient] Rare Drop: Manti-core!")
    },200)}
}).setCriteria("RARE DROP! Manti-core")

register("chat", () => {
    if (Config.inq) {
    setTimeout(() => {
        ChatLib.command("pc [BakerClient] Rare Diana Mob: Inquisitor!")
    },200)
    setTimeout(() => {
        ChatLib.command(getCoordsMessage());
    },1200)}
}).setCriteria("Woah! You dug out a Minos Inquisitor!")

register("chat", () => {
    if (Config.inq) {
    setTimeout(() => {
        ChatLib.command("pc [BakerClient] Rare Diana Mob: Inquisitor!")
    },200)
    setTimeout(() => {
        ChatLib.command(getCoordsMessage());
    },1200)}
}).setCriteria("Oi! You dug out a Minos Inquisitor!")

register("chat", () => {
    if (Config.inq) {
    setTimeout(() => {
        ChatLib.command("pc [BakerClient] Rare Diana Mob: Inquisitor!")
    },200)
    setTimeout(() => {
        ChatLib.command(getCoordsMessage());
    },1200)}
}).setCriteria("Danger! You dug out a Minos Inquisitor!")

register("chat", () => {
    if (Config.inq) {
    setTimeout(() => {
        ChatLib.command("pc [BakerClient] Rare Diana Mob: Inquisitor!")
    },200)
    setTimeout(() => {
        ChatLib.command(getCoordsMessage());
    },1200)}
}).setCriteria("Uh oh! You dug out a Minos Inquisitor!")

register("chat", () => {
    if (Config.inq) {
    setTimeout(() => {
        ChatLib.command("pc [BakerClient] Rare Diana Mob: Inquisitor!")
    },200)
    setTimeout(() => {
        ChatLib.command(getCoordsMessage());
    },1200)}
}).setCriteria("Good Grief! You dug out a Minos Inquisitor!")

register("chat", () => {
    if (Config.inq) {
    setTimeout(() => {
        ChatLib.command("pc [BakerClient] Rare Diana Mob: Inquisitor!")
    },200)
    setTimeout(() => {
        ChatLib.command(getCoordsMessage());
    },1200)}
}).setCriteria("Yikes! You dug out a Minos Inquisitor!")

register("chat", () => {
    if (Config.inq) {
    setTimeout(() => {
        ChatLib.command("pc [BakerClient] Rare Diana Mob: Inquisitor!")
    },200)
    setTimeout(() => {
        ChatLib.command(getCoordsMessage());
    },1200)}
}).setCriteria("Oh! You dug out a Minos Inquisitor!")

register("chat", () => {
    if (Config.manti) {
    setTimeout(() => {
        ChatLib.command("pc [BakerClient] Rare Diana Mob: Manticore!")
    },200)
    setTimeout(() => {
        ChatLib.command(getCoordsMessage());
    },coorddelay)}
}).setCriteria("Woah! You dug out a Manticore!")

register("chat", () => {
    if (Config.manti) {
    setTimeout(() => {
        ChatLib.command("pc [BakerClient] Rare Diana Mob: Manticore!")
    },200)
    setTimeout(() => {
        ChatLib.command(getCoordsMessage());
    },coorddelay)}
}).setCriteria("Oi! You dug out a Manticore!")

register("chat", () => {
    if (Config.manti) {
    setTimeout(() => {
        ChatLib.command("pc [BakerClient] Rare Diana Mob: Manticore!")
    },200)
    setTimeout(() => {
        ChatLib.command(getCoordsMessage());
    },coorddelay)}
}).setCriteria("Danger! You dug out a Manticore!")

register("chat", () => {
    if (Config.manti) {
    setTimeout(() => {
        ChatLib.command("pc [BakerClient] Rare Diana Mob: Manticore!")
    },200)
    setTimeout(() => {
        ChatLib.command(getCoordsMessage());
    },coorddelay)}
}).setCriteria("Uh oh! You dug out a Manticore!")

register("chat", () => {
    if (Config.manti) {
    setTimeout(() => {
        ChatLib.command("pc [BakerClient] Rare Diana Mob: Manticore!")
    },200)
    setTimeout(() => {
        ChatLib.command(getCoordsMessage());
    },coorddelay)}
}).setCriteria("Good Grief! You dug out a Manticore!")

register("chat", () => {
    if (Config.manti) {
    setTimeout(() => {
        ChatLib.command("pc [BakerClient] Rare Diana Mob: Manticore!")
    },200)
    setTimeout(() => {
        ChatLib.command(getCoordsMessage());
    },coorddelay)}
}).setCriteria("Yikes! You dug out a Manticore!")

register("chat", () => {
    if (Config.manti) {
    setTimeout(() => {
        ChatLib.command("pc [BakerClient] Rare Diana Mob: Manticore!")
    },200)
    setTimeout(() => {
        ChatLib.command(getCoordsMessage());
    },coorddelay)}
}).setCriteria("Oh! You dug out a Manticore!")

register("chat", () => {
    if (Config.sphinx) {
    setTimeout(() => {
        ChatLib.command("pc [BakerClient] Rare Diana Mob: Sphinx!")
    },200)
    setTimeout(() => {
        ChatLib.command(getCoordsMessage());
    },coorddelay)}
}).setCriteria("Danger! You dug out a Sphinx!")

register("chat", () => {
    if (Config.sphinx) {
    setTimeout(() => {
        ChatLib.command("pc [BakerClient] Rare Diana Mob: Sphinx!")
    },200)
    setTimeout(() => {
        ChatLib.command(getCoordsMessage());
    },coorddelay)}
}).setCriteria("Oi! You dug out a Sphinx!")

register("chat", () => {
    if (Config.sphinx) {
    setTimeout(() => {
        ChatLib.command("pc [BakerClient] Rare Diana Mob: Sphinx!")
    },200)
    setTimeout(() => {
        ChatLib.command(getCoordsMessage());
    },coorddelay)}
}).setCriteria("Uh oh! You dug out a Sphinx!")

register("chat", () => {
    if (Config.sphinx) {
    setTimeout(() => {
        ChatLib.command("pc [BakerClient] Rare Diana Mob: Sphinx!")
    },200)
    setTimeout(() => {
        ChatLib.command(getCoordsMessage());
    },coorddelay)}
}).setCriteria("Good Grief! You dug out a Sphinx!")

register("chat", () => {
    if (Config.sphinx) {
    setTimeout(() => {
        ChatLib.command("pc [BakerClient] Rare Diana Mob: Sphinx!")
    },200)
    setTimeout(() => {
        ChatLib.command(getCoordsMessage());
    },coorddelay)}
}).setCriteria("Yikes! You dug out a Sphinx!")

register("chat", () => {
    if (Config.sphinx) {
    setTimeout(() => {
        ChatLib.command("pc [BakerClient] Rare Diana Mob: Sphinx!")
    },200)
    setTimeout(() => {
        ChatLib.command(getCoordsMessage());
    },coorddelay)}
}).setCriteria("Oh! You dug out a Sphinx!")

register("chat", () => {
    if (Config.king) {
    setTimeout(() => {
        ChatLib.command("pc [BakerClient] Rare Diana Mob: King Minos!")
    },200)
    setTimeout(() => {
        ChatLib.command(getCoordsMessage());
    },coorddelay)}
}).setCriteria("Oh! You dug out a King Minos!")

register("chat", () => {
    if (Config.king) {
    setTimeout(() => {
        ChatLib.command("pc [BakerClient] Rare Diana Mob: King Minos!")
    },200)
    setTimeout(() => {
        ChatLib.command(getCoordsMessage());
    },coorddelay)}
}).setCriteria("Woah! You dug out a King Minos!")

register("chat", () => {
    if (Config.king) {
    setTimeout(() => {
        ChatLib.command("pc [BakerClient] Rare Diana Mob: King Minos!")
    },200)
    setTimeout(() => {
        ChatLib.command(getCoordsMessage());
    },coorddelay)}
}).setCriteria("Oi! You dug out a King Minos!")

register("chat", () => {
    if (Config.king) {
    setTimeout(() => {
        ChatLib.command("pc [BakerClient] Rare Diana Mob: King Minos!")
    },200)
    setTimeout(() => {
        ChatLib.command(getCoordsMessage());
    },coorddelay)}
}).setCriteria("Danger! You dug out a King Minos!")

register("chat", () => {
    if (Config.king) {
    setTimeout(() => {
        ChatLib.command("pc [BakerClient] Rare Diana Mob: King Minos!")
    },200)
    setTimeout(() => {
        ChatLib.command(getCoordsMessage());
    },coorddelay)}
}).setCriteria("Uh oh! You dug out a King Minos!")

register("chat", () => {
    if (Config.king) {
    setTimeout(() => {
        ChatLib.command("pc [BakerClient] Rare Diana Mob: King Minos!")
    },200)
    setTimeout(() => {
        ChatLib.command(getCoordsMessage());
    },coorddelay)}
}).setCriteria("Good Grief! You dug out a King Minos!")

register("chat", () => {
    if (Config.king) {
    setTimeout(() => {
        ChatLib.command("pc [BakerClient] Rare Diana Mob: King Minos!")
    },200)
    setTimeout(() => {
        ChatLib.command(getCoordsMessage());
    },coorddelay)}
}).setCriteria("Yikes! You dug out a King Minos!")

// chat flood

register("chat", (milestone) => {
    if (Config.milestone) {
        // Convert the unicode to real numbers
        const map = {
            "❶": 1, "❷": 2, "❸": 3, "❹": 4, "❺": 5,
            "❻": 6, "❼": 7, "❽": 8, "❾": 9
        };

        const num = map[milestone] ?? milestone; // fallback if weird formatting

        setTimeout(() => {
            ChatLib.command(`pc I got Milestone ${num}!`)
        }, 200);
    }
}).setCriteria(/Milestone ([❶❷❸❹❺❻❼❽❾])/);

register("chat", () => {
    if (Config.raredrop) {
    setTimeout(() => {
        ChatLib.command("pc I got a Rare Drop!")
    },200)}
}).setCriteria(/RARE DROP!/)

register("chat", () => {
    if (Config.dooropen) {
    setTimeout(() => {
        ChatLib.command("pc Wither Door Opened!")
    },200)}
}).setCriteria(/opened a WITHER door!/)

register("chat", () => {
    if (Config.dooropen) {
    setTimeout(() => {
        ChatLib.command("pc Blood Door Opened!")
    },200)}
}).setCriteria(/BOSS The Watcher: Things feel a little more roomy now, eh?/)

register("chat", () => {
    if (Config.obtained) {
    setTimeout(() => {
        ChatLib.command("pc Someone in the party has gotten something!")
    },200)}
}).setCriteria(/ has obtained /)

register("chat", () => {
    if (Config.friend) {
    setTimeout(() => {
        ChatLib.command("pc My friend left hypixel :(")
    },200)}
}).setCriteria(/Friend >.* left/)

register("chat", () => {
    if (Config.friend) {
    setTimeout(() => {
        ChatLib.command("pc My friend joined hypixel :)")
    },200)}
}).setCriteria(/Friend >.* joined/)

register("chat", () => {
    if (Config.gexp) {
    setTimeout(() => {
        ChatLib.command("pc I earned GEXP!")
    },200)}
}).setCriteria(/You earned .* GEXP/)

register("chat", () => {
    if (Config.Atopet) {
    setTimeout(() => {
        ChatLib.command("pc Autopet rules triggered!")
    },200)}
}).setCriteria(/Autopet equipped your/)

register("chat", () => {
    if (Config.watchr) {
    setTimeout(() => {
        ChatLib.command("pc Watcher Move!")
    },200)}
}).setCriteria(/he Watcher: Let's see how you can handle this/)

register("chat", () => {
    if (Config.bloodcamp) {
    setTimeout(() => {
        ChatLib.command("pc Blood Camp Done!")
    },200)}
}).setCriteria(/The Watcher: You have proven yourself. You may pass/)

register("chat", () => {
    if (Config.crystalpickup) {
    setTimeout(() => {
        ChatLib.command("pc Energy Crystal Picked Up!")
    },200)}
}).setCriteria(/ picked up an Energy Crystal!/)

register("chat", () => {
    if (Config.crystalplaced) {
    setTimeout(() => {
        ChatLib.command("pc Energy Crystal Placed!")
    },200)}
}).setCriteria(/Energy Crystals are now active!/)

register("chat", () => {
    if (Config.lasercharge) {
    setTimeout(() => {
        ChatLib.command("pc Energy Laser Charging...")
    },200)}
}).setCriteria(/The Energy Laser is charging up!/)

register("chat", () => {
    if (Config.maxorenrage) {
    setTimeout(() => {
        ChatLib.command("pc Maxor is enraged!")
    },200)}
}).setCriteria(/⚠ Maxor is enraged! ⚠/)

register("chat", () => {
    if (Config.lightning) {
    setTimeout(() => {
        ChatLib.command("pc Lightning Warning!")
    },200)}
}).setCriteria(/Storm: I'd be happy to show you what that's like!/)

register("chat", () => {
    if (Config.crush) {
    setTimeout(() => {
        ChatLib.command("pc Storm Crushed!")
    },200)}
}).setCriteria(/Storm: Ouch, that hurt!/)

register("chat", () => {
    if (Config.stormenrage) {
    setTimeout(() => {
        ChatLib.command("pc Storm is enraged!")
    },200)}
}).setCriteria(/⚠ Storm is enraged! ⚠/)

register("chat", () => {
    if (Config.grief) {
    setTimeout(() => {
        ChatLib.command("pc Storm is grieving!")
    },200)}
}).setCriteria(/Storm: At least my son died by your hands/)

register("chat", () => {
    if (Config.p3start) {
    setTimeout(() => {
        ChatLib.command("pc P3 Start!")
    },200)}
}).setCriteria(/Goldor: Who dares trespass into my domain/)

register("chat", () => {
    if (Config.inboss) {
    setTimeout(() => {
        ChatLib.command("pc In Boss!")
    },200)}
}).setCriteria(/Maxor: WELL! WELL! WELL! LOOK WHO'S HERE!/)

register("chat", () => {
    if (Config.wish) {
    setTimeout(() => {
        ChatLib.command("pc Wished!")
    },200)}
}).setCriteria(/Wish healed you for/)

register("chat", () => {
    if (Config.mdead) {
    setTimeout(() => {
        ChatLib.command("pc Maxor Dead!")
    },200)}
}).setCriteria(/Maxor: I'M TOO YOUNG TO DIE AGAIN!/)

register("chat", () => {
    if (Config.p2start) {
    setTimeout(() => {
        ChatLib.command("pc P2 Start!")
    },200)}
}).setCriteria(/Storm: Pathetic Maxor, just like expected/)

register("chat", () => {
    if (Config.crush) {
    setTimeout(() => {
        ChatLib.command("pc Storm Crushed!")
    },200)}
}).setCriteria(/Storm: Oof/)

register("chat", () => {
    if (Config.p4start) {
    setTimeout(() => {
        ChatLib.command("pc P4 Start!")
    },200)}
}).setCriteria(/Necron: You went further than any human before, congratulations/)

register("chat", () => {
    if (Config.p5start) {
    setTimeout(() => {
        ChatLib.command("pc P5 Start!")
    },200)}
}).setCriteria(/Necron: All this, for nothing/)

register("chat", () => {
    if(Config.roseref) {
    setTimeout(() => {
        ChatLib.command("pc Im a DEMON")
    },200)
    setTimeout(() => {
        ChatLib.command("pc IM SO SAD")
    },1200)
    setTimeout(() => {
        ChatLib.command("pc EVERYONE HATES ME")
    },2200)
    setTimeout(() => {
        ChatLib.command("pc STOP TALKING TO ME IM SO SAD")
    },3200)
    setTimeout(() => {
        ChatLib.command("pc IM SO DEPRESSED AND WANT TO DIE")
    },4200)}
}).setCriteria(/^Party > (?:\\[(.*?)\\] )?(.+?) ?(?:\u127E|\u2692)?: !roseref$/)

register("chat", () => {
    if(Config.hazelref) {
    setTimeout(() => {
        ChatLib.command("pc PLEASE IM BEGGING YOU")
    },200)
    setTimeout(() => {
        ChatLib.command("pc PLEASE SAVE ME")
    },1200)
    setTimeout(() => {
        ChatLib.command("pc AYMA PLEASE ANYTHING YOU WANT PLEASE")
    },2200)
    setTimeout(() => {
        ChatLib.command("pc GET HIM OUT OF MY LIFE PLEASE")
    },3200)
    setTimeout(() => {
        ChatLib.command("pc @ARROW ik its bad to beg you to ban someone i dont like but please")
    },4200)}
}).setCriteria(/^Party > (?:\\[(.*?)\\] )?(.+?) ?(?:\u127E|\u2692)?: !hazelref$/)

register("chat", () => {
    if(Config.devref) {
    setTimeout(() => {
        ChatLib.command("pc I am NOT an egg!")
    },200)}
}).setCriteria(/^Party > (?:\\[(.*?)\\] )?(.+?) ?(?:\u127E|\u2692)?: !devref$/)

register("chat", () => {
    if(Config.leonref) {
    setTimeout(() => {
        ChatLib.command("pc whos my little discord kitten")
    },200)}
}).setCriteria(/^Party > (?:\\[(.*?)\\] )?(.+?) ?(?:\u127E|\u2692)?: !leonref$/)

register("chat", () => {
    if(Config.martref) {
    setTimeout(() => {
        ChatLib.command("pc IT'S S PLUS OMG IT'S S PLUS GUYS IT'S ACTUALLY S PLUS")
    },200)}
}).setCriteria(/^Party > (?:\\[(.*?)\\] )?(.+?) ?(?:\u127E|\u2692)?: !martref$/)

register("chat", () => {
    if(Config.jqnxcref) {
    setTimeout(() => {
        ChatLib.command("pc why are you calling my friend a pdf without proof?")
    },200)
    setTimeout(() => {
        ChatLib.command("pc no i dont wanna read the proof")
    },1200)
    setTimeout(() => {
        ChatLib.command("pc can we kick this guy?")
    },2200)
    setTimeout(() => {
        ChatLib.command("pc asking for proof != defending btw")
    },3200)}
}).setCriteria(/^Party > (?:\\[(.*?)\\] )?(.+?) ?(?:\u127E|\u2692)?: !jqnxcref$/)

register("chat", () => {
    if(Config.dexref) {
    setTimeout(() => {
        ChatLib.command("pc my cute little ekitten")
    },200)
    setTimeout(() => {
        ChatLib.command("pc maxdragonis i4 ee2 core")
    },1200)
    setTimeout(() => {
        ChatLib.command("pc isnt 49s storm wr")
    },2200)
    setTimeout(() => {
        ChatLib.command("pc diivaks is no longer ready!")
    },3200)
    setTimeout(() => {
        ChatLib.command("pc ☠ diivaks was killed by Withermancer and became a ghost. (4)")
    },4200)}
}).setCriteria(/^Party > (?:\\[(.*?)\\] )?(.+?) ?(?:\u127E|\u2692)?: !dexref$/)

register("chat", () => {
    if(Config.sixseven) {
    setTimeout(() => {
        ChatLib.command("pc 6767676767676767676767676767676767")
    },200)
    setTimeout(() => {
        ChatLib.command("pc 6767676767676767676767676767676767")
    },600)
    setTimeout(() => {
        ChatLib.command("pc 6767676767676767676767676767676767")
    },1000)
    setTimeout(() => {
        ChatLib.command("pc 6767676767676767676767676767676767")
    },1400)}
}).setCriteria(/^Party > (?:\\[(.*?)\\] )?(.+?) ?(?:\u127E|\u2692)?: !67$/)

register("chat", () => {
    if(Config.schizoref) {
    setTimeout(() => {
        ChatLib.command("pc best player")
    },200)
    setTimeout(() => {
        ChatLib.command("pc no debate")
    },1200)
    setTimeout(() => {
        ChatLib.command("pc impossible for him to have a ref")
    },2200)
    setTimeout(() => {
        ChatLib.command("pc 67")
    },3200)}
}).setCriteria(/^Party > (?:\\[(.*?)\\] )?(.+?) ?(?:\u127E|\u2692)?: !cataholicref$/)

register("chat", () => {
    if(Config.thearef) {
    setTimeout(() => {
        ChatLib.command("pc look tic tac toe is hard")
    },200)
    setTimeout(() => {
        ChatLib.command("pc you cant blame me")
    },1200)
    setTimeout(() => {
        ChatLib.command("pc sorry i ratted you it was an accident i swear")
    },2200)
    setTimeout(() => {
        ChatLib.command("pc my pb is 4 days withou a ban")
    },3200)}
}).setCriteria(/^Party > (?:\\[(.*?)\\] )?(.+?) ?(?:\u127E|\u2692)?: !thearef$/)

register("chat", () => {
    if(Config.stenoref) {
    setTimeout(() => {
        ChatLib.command("pc spring boots?")
    },200)
    setTimeout(() => {
        ChatLib.command("pc i thought jerry gun was still meta for crystals")
    },1200)
    setTimeout(() => {
        ChatLib.command("pc is 35s maxor bad?")
    },2200)}
}).setCriteria(/^Party > (?:\\[(.*?)\\] )?(.+?) ?(?:\u127E|\u2692)?: !stenoref$/)

register("chat", () => {
    if(Config.hozoniref) {
    setTimeout(() => {
        ChatLib.command("pc how can hozoni have a ref")
    },200)
    setTimeout(() => {
        ChatLib.command("pc he's too nonchalant for that shit")
    },1200)}
}).setCriteria(/^Party > (?:\\[(.*?)\\] )?(.+?) ?(?:\u127E|\u2692)?: !hozoniref$/)

register("chat", () => {
    if(Config.melonref) {
    setTimeout(() => {
        ChatLib.command("pc melon roles")
    },200)
    setTimeout(() => {
        ChatLib.command("pc 15 second p3")
    },1200)
    setTimeout(() => {
        ChatLib.command("pc sub 4:20 cas")
    },2200)}
}).setCriteria(/^Party > (?:\\[(.*?)\\] )?(.+?) ?(?:\u127E|\u2692)?: !melonref$/)

register("chat", (msg) => {
    if (Config.holydt) {
        if (/holy dt/i.test(msg)) return;
        setTimeout(() => {
            ChatLib.command("pc holy dt")
        }, 200)}
}).setCriteria(/^(.*dt.*)$/)

register("chat", (msg) => {
    if (Config.onesec) {
        if (/holy fat/i.test(msg)) return;
        setTimeout(() => {
            ChatLib.command("pc holy fat")
        }, 200)}
}).setCriteria(/^(.*1s.*)$/)

register("chat", (msg) => {
    if (Config.ilove67) {
        if (/i love 67/i.test(msg)) return;
        setTimeout(() => {
            ChatLib.command("pc i love 67")
        }, 200)}
}).setCriteria(/^(.*67.*)$/)

register("chat", () => {
    if(Config.harryref) {
    setTimeout(() => {
        ChatLib.command("pc This content contains explicit content and can not be shown")
    },200)}
}).setCriteria(/^Party > (?:\\[(.*?)\\] )?(.+?) ?(?:\u127E|\u2692)?: !harryref$/)
