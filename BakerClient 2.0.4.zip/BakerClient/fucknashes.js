import Config from "./config"

register("chat", () => {
    if(Config.fucknashesmessage) {
    setTimeout(() => {
        ChatLib.command("pc Fuck Nashes")
    },200)}
    if(Config.fucknashes) {
    setTimeout(() => {
        ChatLib.command("p kick nashes")
    },1200)}
}).setCriteria(/^Party > (?:\\[(.*?)\\] )?(.+?) ?(?:\u127E|\u2692)?: i'm nashes$/i)

register("chat", () => {
    if(Config.fucknashesmessage) {
    setTimeout(() => {
        ChatLib.command("pc Fuck Nashes")
    },200)}
    if(Config.fucknashes) {
    setTimeout(() => {
        ChatLib.command("p kick nashes")
    },1200)}
}).setCriteria(/^Party > (?:\\[(.*?)\\] )?(.+?) ?(?:\u127E|\u2692)?: im nashes$/i)