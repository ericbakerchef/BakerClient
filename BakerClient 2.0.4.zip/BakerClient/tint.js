import Config from "./config"

register("renderOverlay", () => {
    if (!Config.tint) return

    const percent = Math.max(0, Math.min(100, Config.tintStrength))

    const alpha = Math.floor((percent / 100) * 255)

    const color = Renderer.color(0, 0, 0, alpha)

    Renderer.drawRect(
        color,
        0,
        0,
        Renderer.screen.getWidth(),
        Renderer.screen.getHeight()
    )
})
