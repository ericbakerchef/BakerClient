import Config from "./config"
import request from "../requestV2"

const MAX = 1900
const WEBHOOK_URL = ""
const HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Accept": "*/*"
}
const IGNORE_SUBSTRINGS = [
    "You already tipped everyone that has boosters active, so there isn't anybody to be tipped right now!",
    "You are sending commands too fast! Please slow down.",
    "No one has a network booster active right now! Try again later."
]

const send = (message) => {
    if (!Config.webhook) return
    const url = (WEBHOOK_URL || Config.webhooklink || "").trim()
    if (!url || !message) return
    const clean = ChatLib.removeFormatting(String(message))
    if (IGNORE_SUBSTRINGS.some((s) => clean.includes(s))) return
    const content = clean.length > MAX ? clean.slice(0, MAX - 3) + "..." : clean
    request({ url, method: "POST", headers: HEADERS, body: { content } })
        .catch(() => {})
}

register("chat", (event) => {
    send(ChatLib.getChatMessage(event))
}).setCriteria("${*}")
