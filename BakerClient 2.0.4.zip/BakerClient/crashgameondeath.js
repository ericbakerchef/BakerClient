import Config from "./config"

register('chat', () => {
    if(Config.cgod) {
        
    }
}).setCriteria(/.*You.*became a ghost.*/i);
