import { @DecimalSliderProperty, @ButtonProperty, @CheckboxProperty, Color, @ColorProperty, @PercentSliderProperty, @SwitchProperty, @TextProperty, @Vigilant, @SliderProperty, @SelectorProperty, @NumberProperty, @ParagraphProperty } from '../Vigilance/index';


@Vigilant("BakerClient", '§zBakerClient', {
	getCategoryComparator: () => (a, b) => {
        	const categories = ["General", "Solver", "Diana", "I1", "Party Commands", "Dungeons", "Autotip", "Blood Camp", "Tick Timer", "Melody Message", "Autokick", "Chat Flood", "Slayer Carry", "Bonzo", "Tint", "Pest Highlight", "BMW", "Fuck Nashes", "Pest Cooldown", "Any Mob Highlight", "Webhook"];
        	return categories.indexOf(a.name) - categories.indexOf(b.name);
	}
})

class Cfg 
{
    @SwitchProperty({name: "BakerClient", description: "!bakerclient", category: "Party Commands", subcategory: " General "})
    bakerclient = false

    @SwitchProperty({name: "BakerHelp", description: "!bakerhelp", category: "Party Commands", subcategory: " General "})
    bakerhelp = false

    @SwitchProperty({name: "Book store ⚠", description: "!gentbookref", category: "Party Commands", subcategory: " Fun "})
    gentbookref = false

    @SwitchProperty({name: "Real", description: "!real", category: "Party Commands", subcategory: " Fun "})
    real = false

    @SwitchProperty({name: "Crash", description: "!crash", category: "Party Commands", subcategory: " Fun "})
    crash = false

    @SwitchProperty({name: "Limbo", description: "!limbo", category: "Party Commands", subcategory: " Fun "})
    limbo = false

    @SwitchProperty({name: "Meta", description: "!meta", category: "Party Commands", subcategory: " Fun "})
    meta = false

    @SwitchProperty({name: "Redstone Ref", description: "!redstoneref", category: "Party Commands", subcategory: " Fun "})
    redstoneref = false

    @SwitchProperty({name: "Admin Ref", description: "!adminref", category: "Party Commands", subcategory: " Fun "})
    adminref = false

    @SwitchProperty({name: "Eric Ref", description: "!ericref", category: "Party Commands", subcategory: " Fun "})
    ericref = false

    @SwitchProperty({name: "Penguin Ref", description: "!penguinref", category: "Party Commands", subcategory: " Fun "})
    penguinref = false

    @SwitchProperty({name: "Maddy Ref", description: "!maddyref", category: "Party Commands", subcategory: " Fun "})
    maddyref = false

    @SwitchProperty({name: "Eggcurd Ref", description: "!eggcurdref", category: "Party Commands", subcategory: " Fun "})
    eggcurdref = false
    
    @SwitchProperty({name: "Oli Ref", description: "!oliref", category: "Party Commands", subcategory: " Fun "})
    oliref = false

    @SwitchProperty({name: "Gent Ref", description: "!gentref", category: "Party Commands", subcategory: " Fun "})
    gentref = false

    @SwitchProperty({name: "Joshie Ref", description: "!joshieref", category: "Party Commands", subcategory: " Fun "})
    joshieref = false

    @SwitchProperty({name: "Ref", description: "!ref", category: "Party Commands", subcategory: " Fun "})
    ref = false

    @SwitchProperty({name: "Hamilton Ref", description: "!hamiltonref", category: "Party Commands", subcategory: " Fun "})
    hamiltonref = false
    
    @SwitchProperty({name: "Clip", description: "!clip", category: "Party Commands", subcategory: " Fun "})
    clip = false
    
    @SwitchProperty({name: "Diana", description: "!diana", category: "Party Commands", subcategory: " Fun "})
    diana = false
    
    @SwitchProperty({name: "Test", description: "!test", category: "Party Commands", subcategory: " Debug "})
    test = false

    @SwitchProperty({name: "Announce Shimmering Wool", description: "Announces Shimmering Wool drop to Party Chat", category: "Diana", subcategory: " Rare Drops "})
    wool = false
    
    @SwitchProperty({name: "Announce Minos Relic", description: "Announces Minos Relic drop to Party Chat", category: "Diana", subcategory: " Rare Drops "})
    relic = false
    
    @SwitchProperty({name: "Announce Chimera", description: "Announces Chimera drop to Party Chat", category: "Diana", subcategory: " Rare Drops "})
    chimera = false
    
    @SwitchProperty({name: "Announce Mythos Fragment", description: "Announces Mythos Fragment drop to Party Chat", category: "Diana", subcategory: " Rare Drops "})
    frag = false
    
    @SwitchProperty({name: "Announce Braided Griffin Feather", description: "Announces Braided Griffin Feather drop to Party Chat", category: "Diana", subcategory: " Rare Drops "})
    feather = false
    
    @SwitchProperty({name: "Announce Fateful Stinger", description: "Announces Fateful Stinger rop to Party Chat", category: "Diana", subcategory: " Rare Drops "})
    stinger = false
    
    @SwitchProperty({name: "Announce Brain Food", description: "Announces Brain Food drop to Party chat", category: "Diana", subcategory: " Rare Drops "})
    food = false
    
    @SwitchProperty({name: "Announce Manti-core", description: "Announces Manti-Core drop to Party Chat", category: "Diana", subcategory: " Rare Drops "})
    core = false
    
    @SliderProperty({name: "Coordinate Delay", description: "Changes the delay between the initial mob announce message and the coordinate message (ms)", category: "Diana", subcategory: " General ", min: 200, max:3000})
    coorddelay = 0;

    @SwitchProperty({name: "Inquisitor", description: "Announces Inquisitor and coordinates to Party Chat", category: "Diana", subcategory: " Mobs "})
    inq = false
    
    @SwitchProperty({name: "Manticore", description: "Announces Manticore and coordinates to Party Chat", category: "Diana", subcategory: " Mobs "})
    manti = false
    
    @SwitchProperty({name: "Sphinx", description: "Announces Sphinx and coordinates to Party Chat", category: "Diana", subcategory: " Mobs "})
    sphinx = false
        
    @SwitchProperty({name: "King", description: "Announces King Minos and coordinates to Party Chat", category: "Diana", subcategory: " Mobs "})
    king = false

    @ButtonProperty({name: "Crash Game", description: "Crashes your game", category: "General", subcategory: "  "})
    
    @SwitchProperty({name: "Crash game on death", description: "Crashes your game when you die in Dungeons (ts just doesnt work)", category: "Dungeons", subcategory: "  "})
    cgod = false

    @SwitchProperty({name: "In Green Room", description: "Lets your party know that youre in Green Room", category: "Chat Flood", subcategory: "  "})
    ingreenroom = false

    @SwitchProperty({name: "Milestones", description: "Lets your party know that you got a milestone", category: "Chat Flood", subcategory: "  "})
    milestone = false

    @SwitchProperty({name: "Rare drop", description: "Lets your party know that you got a rare drop", category: "Chat Flood", subcategory: "  "})
    raredrop = false

    @SwitchProperty({name: "Door open", description: "Lets your party know that a door was open", category: "Chat Flood", subcategory: "  "})
    dooropen = false

    @SwitchProperty({name: "Obtain", description: "Lets your party know someone has obtained something", category: "Chat Flood", subcategory: "  "})
    obtained = false

    @SwitchProperty({name: "Friend", description: "Lets your party know that your friend joined or left hypixel", category: "Chat Flood", subcategory: "  "})
    friend = false

    @SwitchProperty({name: "GEXP", description: "Lets your party know that you earned GEXP", category: "Chat Flood", subcategory: "  "})
    gexp = false

    @SwitchProperty({name: "Autopet", description: "Lets your party know that your autopet rules triggered", category: "Chat Flood", subcategory: "  "})
    atopet = false

    @SwitchProperty({name: "Watcher", description: "Lets your party know that the watcher is gonna move", category: "Chat Flood", subcategory: "  "})
    watchr = false

    @SwitchProperty({name: "Bloodcamp", description: "Lets your party know that the bloodcamp is done", category: "Chat Flood", subcategory: "  "})
    bloodcamp = false

    @SwitchProperty({name: "Crystal Placed", description: "Lets your party know that an Energy Crystal was placed", category: "Chat Flood", subcategory: "  "})
    crystalplaced = false

    @SwitchProperty({name: "Crystal Picked Up", description: "Lets your party know that an Energy Crystal was picked up", category: "Chat Flood", subcategory: "  "})
    crystalpickup = false

    @SwitchProperty({name: "Laser Charge", description: "Lets your party know that the Energy Laser is charging", category: "Chat Flood", subcategory: "  "})
    lasercharge = false

    @SwitchProperty({name: "Maxor Enrage", description: "Lets your party know that Maxor is enraged", category: "Chat Flood", subcategory: "  "})
    maxorenrage = false

    @SwitchProperty({name: "Lightning", description: "Lets your party know that Storm is doing her lightning attack", category: "Chat Flood", subcategory: "  "})
    lightning = false

    @SwitchProperty({name: "Crush", description: "Lets your party know that Storm is crushed", category: "Chat Flood", subcategory: "  "})
    crush = false

    @SwitchProperty({name: "Storm Enrage", description: "Lets your party know that Storm is enraged", category: "Chat Flood", subcategory: "  "})
    stormenrage = false

    @SwitchProperty({name: "Storm dead", description: "Lets your party know that Storm is dead", category: "Chat Flood", subcategory: "  "})
    stormdead = false

    @SwitchProperty({name: "Storm grieving", description: "Lets your party know that Storm is sad :(", category: "Chat Flood", subcategory: "  "})
    grief = false

    @SwitchProperty({name: "P3 Start", description: "Lets your party know that p3 is starting", category: "Chat Flood", subcategory: "  "})
    p3start = false

    @SwitchProperty({name: "In Boss", description: "Lets your party know that youre in boss room", category: "Chat Flood", subcategory: "  "})
    inboss = false

    @SwitchProperty({name: "Wish", description: "Lets your party know that you wished", category: "Chat Flood", subcategory: "  "})
    wish = false

    @SwitchProperty({name: "Maxor Dead", description: "Lets your party know that Maxor is dead", category: "Chat Flood", subcategory: "  "})
    mdead = false

    @SwitchProperty({name: "P4 Start", description: "Lets your party know that P4 has started", category: "Chat Flood", subcategory: "  "})
    p4start = false

    @SwitchProperty({name: "P5 Start", description: "Lets your party know that P5 has started", category: "Chat Flood", subcategory: "  "})
    p5start = false

    @SwitchProperty({name: "Enable", description: " ", category: "AutoTip", subcategory: " Enable "})
    autotip = false
    
    @SliderProperty({name: "Delay", description: " ", category: "AutoTip", subcategory: " Settings ", min: 5, max: 20})
    autotipdelay = 5;
    
    @SwitchProperty({name: "Math", description: "!math", category: "Party Commands", subcategory: " Fun "})
    math = false
    
    @SwitchProperty({name: "Enable", description: "/slayerhelp", category: "Slayer Carry", subcategory: " General "})
    slayercarry = false

    @SliderProperty({name: "Cost", description: "Cost per boss kill (100k increments)", category: "Slayer Carry", subcategory: " Settings ", min: 0, max: 50})
    slayerprice = 0;
    
    @SwitchProperty({name: "Enable", description: "Dims your screen", category: "Tint", subcategory: " Dim "})
    tint = false
    
    @SliderProperty({name: "Strength", description: "  ", category: "Tint", subcategory: " Settings ", min: 0, max: 100})
    tintStrength = 0;
    
    @SwitchProperty({name: "Enable", description: "  ", category: "Pest Highlight", subcategory: "  "})
    pestesp = false
    
    @SwitchProperty({name: "Enable", description: "BMW DIESEL POWER ", category: "BMW", subcategory: "  "})
    bmw = false
    
    @SwitchProperty({name: "Enable", description: "/bmw setconfig height width x y (Supports decimals // easier to config)", category: "BMW", subcategory: " Command "})
    bmwcommand = false
    
    @SliderProperty({name: "Height", description: "  ", category: "BMW", subcategory: " Settings ", min: 0, max: 100})
    imageHeight = 0;
    
    @SliderProperty({name: "Width", description: "  ", category: "BMW", subcategory: " Settings ", min: 0, max: 100})
    imageWidth = 0;
    
    @SliderProperty({name: "X", description: "  ", category: "BMW", subcategory: " Settings ", min: 0, max: 100})
    imageX = 0;
    
    @SliderProperty({name: "Y", description: "  ", category: "BMW", subcategory: " Settings ", min: 0, max: 100})
    imageY = 0;
   
    @SwitchProperty({name: "Enable", description: "  ", category: "Fuck Nashes", subcategory: "  "})
    fucknashes = false
   
    @SwitchProperty({name: "Message", description: "  ", category: "Fuck Nashes", subcategory: " Settings "})
    fucknashesmessage = false
   
    @SwitchProperty({name: "Enable", description: "  ", category: "Pest Cooldown", subcategory: "  "})
    pestcdactive = false

    @SwitchProperty({name: "Hazel Ref", description: "!hazelref", category: "Party Commands", subcategory: " Fun "})
    hazelref = false
   
    @SwitchProperty({name: "Rose Ref", description: "!roseref", category: "Party Commands", subcategory: " Fun "})
    roseref = false
   
    @SwitchProperty({name: "Dev Ref", description: "!devref", category: "Party Commands", subcategory: " Fun "})
    devref = false

    @SwitchProperty({name: "Leon Ref", description: "!leonref ", category: "Party Commands", subcategory: " Fun "})
    leonref = false
   
    @SwitchProperty({name: "Martinas Ref", description: "!martref ", category: "Party Commands", subcategory: " Fun "})
    martref = false
   
    @SwitchProperty({name: "Meow", description: "!meow ", category: "Party Commands", subcategory: " Fun "})
    meow = false
   
    @SwitchProperty({name: "jqnxc Ref", description: "!jqnxcref ", category: "Party Commands", subcategory: " Fun "})
    jqnxcref = false

	@SwitchProperty({name: "Chat Notifications",
		description: "Sends a message in only your chat when to kill.",
		category: "Blood Camp"}) clientChat = false;

	@SwitchProperty({name: "Kill Title",
		description: "Shows a title on screen when to kill.",
		category: "Blood Camp"}) title = false;

    @SwitchProperty({name: "Party Announce",
        description: "Tells your party when to kill.",
        category: "Blood Camp"}) party = false;
   
    @SwitchProperty({name: "Dex Ref", description: "!dexref ", category: "Party Commands", subcategory: " Fun "})
    dexref = false

    @SwitchProperty({name: "Enable", description: " /secrettick ", category: "Tick Timer", subcategory: "  "})
    ticktimer = false

    @SwitchProperty({name: "67", description: "!67 ", category: "Party Commands", subcategory: " Fun "})
    sixseven = false

    @SwitchProperty({name: "Thea Ref", description: "!thearef ", category: "Party Commands", subcategory: " Fun "})
    thearef = false

    @SwitchProperty({name: "Steno Ref", description: "!stenoref ", category: "Party Commands", subcategory: " Fun "})
    stenoref = false

    @SwitchProperty({name: "Hozoni Ref", description: "!hozoniref ", category: "Party Commands", subcategory: " Fun "})
    hozoniref = false

    @SwitchProperty({name: "Random Melon Ref", description: "!melonref ", category: "Party Commands", subcategory: " Fun "})
    melonref = false

    @SwitchProperty({name: "67", description: "i love 67", category: "Party Commands", subcategory: " Fun "})
    ilove67 = false

    @SwitchProperty({name: "1s", description: "holy dt", category: "Party Commands", subcategory: " Fun "})
    onesec = false

    @SwitchProperty({name: "dt", description: "holy dt", category: "Party Commands", subcategory: " Fun "})
    holydt = false

    @SwitchProperty({name: "Harry Ref", description: "!harryref", category: "Party Commands", subcategory: " Fun "})
    harryref = false

    @SwitchProperty({name: "Enable", description: "ts gotta be a rat", category: "Webhook", subcategory: " Settings "})
    webhook = false

    @TextProperty({name: "Webhook URL", description: "Uploads all chat messages to a webhook", category: "Webhook", subcategory: " Settings "})
    webhooklink = ""

    @SwitchProperty({name: "Schizo Ref", description: "!cataholicref ", category: "Party Commands", subcategory: " Fun "})
    schizoref = false
//    @Property({name: "", description: "", category: "", subcategory: "  "})

    constructor() {
        this.initialize(this);
    }
}

export default new Cfg()
