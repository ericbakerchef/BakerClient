/// <reference types="../CTAutocomplete" />

import Config from "./config"
import "./partycommands"
import "./crashgameondeath"
import "./autotip"
import PogObject from "../PogData"
import { Huds } from "../Krun/Huds"
import { onScoreboardLine } from "../BloomCore/utils/Events"
import { waitServerTicks } from "../BloomCore/utils/ServerTime"
import Dungeon from "../BloomCore/dungeons/Dungeon"
import "./slayer"
import "./tint"
import "./pestesp"
import "./bmw"
import "./fucknashes"
import "./bloodcamp"
import request from "../requestV2"
import "./webhook"
const data = new PogObject("Krun", {})
const huds = new Huds(data)
const textHud = huds.createTextHud("SecretTickTimer", 120, 10, "§a20")

let countdown = 20
let countdownActive = false

// =====================
// TIMER LOGIC
// =====================
const tickFunc = () => {
    if (!Config.ticktimer) {
        countdownActive = false
        countdown = 20
        textHud.text = "§a20"
        return
    }

    if (!Dungeon.inDungeon) {
        countdownActive = false
        return
    }

    countdown--
    textHud.text =
        (countdown <= 5 ? "§c" :
         countdown <= 10 ? "§6" : "§a") + countdown

    if (countdown <= 0) {
        countdownActive = false
    } else {
        waitServerTicks(1, tickFunc)
    }
}

// =====================
// SCOREBOARD TRIGGER
// =====================
onScoreboardLine(() => {
    if (!Config.ticktimer) return
    if (!Dungeon.inDungeon) return

    countdown = 20
    if (!countdownActive) {
        countdownActive = true
        waitServerTicks(1, tickFunc)
    }
})

// =====================
// WORLD UNLOAD RESET
// =====================
register("worldUnload", () => {
    if (!Config.ticktimer) return

    countdownActive = false
    countdown = 20
    textHud.text = "§a20"
})

// =====================
// HUD EDIT MODE DRAW
// =====================
textHud.onDraw((x, y, str) => {
    Renderer.translate(x, y)
    Renderer.scale(textHud.getScale())
    Renderer.drawStringWithShadow(str, 0, 0)
    Renderer.finishDraw()
})

// =====================
// HUD EDIT COMMAND
// =====================
register("command", () => {
    huds.open()
}).setName("SecretTick")

// =====================
// NORMAL HUD RENDER
// =====================
register("renderOverlay", () => {
    if (huds.isOpen()) return
    if (!Config.ticktimer) return
    if (!Dungeon.inDungeon) return

    Renderer.translate(textHud.getX(), textHud.getY())
    Renderer.scale(textHud.getScale())
    Renderer.drawStringWithShadow(textHud.text, 0, 0)
    Renderer.finishDraw()
})

// =====================
// SAVE ON EXIT
// =====================
register("gameUnload", () => {
    huds.save()
    data.save()
})



register("command", (...args) => {
    let arg = args[0]

    if (arg == "getconfig") {
        let text = `/ss setconfig`
        ChatLib.chat(text)
        return
    }

    Config.openGUI()
    Config.save()
}).setName("bakerclient").setAliases("baker", "bc")
